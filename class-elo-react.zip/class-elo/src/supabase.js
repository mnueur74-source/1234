import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Without these two variables the app runs in local demo mode (data stays in this browser).
export const hasBackend = Boolean(url && key);
export const supabase = hasBackend ? createClient(url, key) : null;

export async function loadRemote() {
  const { data, error } = await supabase.from("league_state").select("data").eq("id", 1).maybeSingle();
  if (error) throw error;
  return data ? data.data : null;
}

export async function saveRemote(state) {
  const { error } = await supabase.from("league_state").upsert({ id: 1, data: state, updated_at: new Date().toISOString() });
  if (error) throw error;
}
