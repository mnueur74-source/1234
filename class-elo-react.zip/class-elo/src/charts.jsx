export function Spark({ points }) {
  if (points.length < 2) return <div className="empty">No matches played yet.</div>;
  const W = 560, H = 180, p = 30;
  const rs = points.map(x => x.r), lo = Math.min(...rs) - 5, hi = Math.max(...rs) + 5;
  const x = i => p + (i / (points.length - 1)) * (W - 2 * p);
  const y = r => H - p - ((r - lo) / (hi - lo)) * (H - 2 * p);
  const d = points.map((q, i) => (i ? "L" : "M") + x(i).toFixed(1) + " " + y(q.r).toFixed(1)).join(" ");
  return (
    <svg className="chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Elo history">
      <path d={d} fill="none" stroke="#1f4fd1" strokeWidth="2.5" />
      {points.map((q, i) => <circle key={i} cx={x(i)} cy={y(q.r)} r="3.5" fill="#1f4fd1"><title>{q.d}: {q.r}</title></circle>)}
      <text x={4} y={14} fontSize="12" fill="#5b6e60">{hi}</text>
      <text x={4} y={H - 8} fontSize="12" fill="#5b6e60">{lo}</text>
    </svg>
  );
}

export function LineChart({ series, labels }) {
  if (labels.length < 2 || !series.length) return <div className="empty">Pick players and log some matches to see the graph.</div>;
  const W = 760, H = 300, pl = 44, pr = 16, pt = 16, pb = 28;
  const all = series.flatMap(x => x.ys), lo = Math.min(...all) - 5, hi = Math.max(...all) + 5;
  const x = i => pl + (i / (labels.length - 1)) * (W - pl - pr);
  const y = r => H - pb - ((r - lo) / (hi - lo)) * (H - pt - pb);
  const ticks = [0, 1, 2, 3].map(k => Math.round(lo + (k / 3) * (hi - lo)));
  return (
    <svg className="chart" style={{ maxWidth: "100%" }} viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Elo over time">
      {ticks.map(t => <g key={t}><line x1={pl} x2={W - pr} y1={y(t)} y2={y(t)} stroke="#c9d4c4" /><text x={4} y={y(t) + 4} fontSize="12" fill="#5b6e60">{t}</text></g>)}
      <text x={pl} y={H - 8} fontSize="12" fill="#5b6e60">start</text>
      <text x={W - pr} y={H - 8} fontSize="12" fill="#5b6e60" textAnchor="end">{labels[labels.length - 1]}</text>
      {series.map(se => (
        <g key={se.id}>
          <path d={se.ys.map((r, i) => (i ? "L" : "M") + x(i).toFixed(1) + " " + y(r).toFixed(1)).join(" ")} fill="none" stroke={se.color} strokeWidth="2.5" />
          {se.ys.map((r, i) => <circle key={i} cx={x(i)} cy={y(r)} r="3" fill={se.color}><title>{se.name}, {labels[i]}: {r}</title></circle>)}
        </g>
      ))}
    </svg>
  );
}

export function Stacked({ rows, sc }) {
  const seg = t => [["Goals", t.g * sc.goal, "#1f4fd1"], ["Assists", t.a * sc.assist, "#0e9aa7"], ["MVP", t.mvp * sc.mvp, "#c79a00"], ["Highlights", t.hlp, "#8a2be2"], ["Clean sheets", t.cs * sc.cs, "#1a7a3c"]];
  const mx = Math.max(1, ...rows.map(r => seg(r.t).reduce((a, x) => a + Math.max(0, x[1]), 0)));
  return (
    <div>
      <div className="legend" style={{ marginBottom: 10 }}>{seg({ g: 0, a: 0, mvp: 0, hlp: 0, cs: 0 }).map(x => <span key={x[0]}><i style={{ background: x[2] }} />{x[0]}</span>)}</div>
      {rows.map(r => (
        <div className="srow" key={r.id}>
          <b>{r.name}</b>
          <div className="sbar">{seg(r.t).map(x => x[1] > 0 && <i key={x[0]} title={x[0] + ": " + x[1]} style={{ width: (x[1] / mx * 100) + "%", background: x[2] }} />)}</div>
          <span className="num">{r.t.pts}</span>
        </div>
      ))}
    </div>
  );
}
