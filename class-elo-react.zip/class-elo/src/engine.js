export const KEY = "class-elo-v1";
export const uid = () => Math.random().toString(36).slice(2, 9);
export const today = () => {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
};
// A season lasts 2 months from its start date.
export const endOf = st => {
  const [y, m, d] = st.split("-").map(Number);
  return new Date(Date.UTC(y, m + 1, d - 1)).toISOString().slice(0, 10);
};
const utc = z => { const [y, m, d] = z.split("-").map(Number); return Date.UTC(y, m - 1, d); };
export const statusOf = se => {
  const t = today(), e = endOf(se.start);
  if (t < se.start) return "Upcoming";
  if (t > e) return "Ended";
  return "Active, " + Math.round((utc(e) - utc(t)) / 864e5) + " days left";
};
export const COLORS = ["#1f4fd1", "#d1491f", "#1a7a3c", "#8a2be2", "#c79a00", "#0e9aa7", "#c2185b", "#5d4037", "#455a64", "#7cb342"];

export const DEF = {
  start: 1000,
  scoring: { goal: 3, assist: 2, mvp: 15, foul: -5, cs: 5 },
  players: [],
  seasons: [{ id: "s1", name: "Season 1", start: today() }],
  tournaments: [{ id: "t1", seasonId: "s1", name: "League" }],
  matches: []
};
export const migrate = d => {
  const m = { ...DEF, ...(d || {}) };
  m.seasons = m.seasons.map(x => (x.start ? x : { ...x, start: today() }));
  return m;
};

export const pts = (l, sc) => l.goals * sc.goal + l.assists * sc.assist + (l.mvp ? sc.mvp : 0) + l.hl + l.fouls * sc.foul + (l.cs ? sc.cs : 0);
export const sortM = ms => [...ms].sort((a, b) => a.date.localeCompare(b.date));

export function totals(ms, sc) {
  const t = {};
  ms.forEach(m => m.lines.forEach(l => {
    const x = t[l.pid] || (t[l.pid] = { pts: 0, g: 0, a: 0, mvp: 0, hl: 0, hlp: 0, f: 0, cs: 0, m: 0 });
    x.pts += pts(l, sc); x.g += l.goals; x.a += l.assists; x.mvp += l.mvp ? 1 : 0;
    x.hl += l.hl ? 1 : 0; x.hlp += l.hl; x.f += l.fouls; x.cs += l.cs ? 1 : 0; x.m++;
  }));
  return t;
}

export function computeAwards(ms, players, sc) {
  const t = totals(ms, sc);
  const rows = players.filter(p => t[p.id]).map(p => ({ name: p.name, ...t[p.id] }));
  const best = (title, desc, key, unit) => ({
    title, desc, unit,
    top: rows.filter(r => r[key] > 0).sort((a, b) => b[key] - a[key] || b.pts - a.pts).slice(0, 3).map(r => ({ name: r.name, val: r[key] }))
  });
  const fair = {
    title: "Fair Play", desc: "Fewest fouls (3+ matches)", unit: "fouls",
    top: rows.filter(r => r.m >= 3).sort((a, b) => a.f - b.f || b.pts - a.pts).slice(0, 3).map(r => ({ name: r.name, val: r.f }))
  };
  return [
    best("Ballon d'Or", "Most points in the season", "pts", "pts"),
    best("Golden Boot", "Most goals", "g", "goals"),
    best("Golden Assist", "Most assists", "a", "assists"),
    best("Golden Glove", "Most clean sheets", "cs", "clean sheets"),
    best("Season MVP", "Most MVP awards", "mvp", "MVPs"),
    best("Highlight Reel", "Most highlight points", "hlp", "pts"),
    fair,
    best("Iron Man", "Most matches played", "m", "matches")
  ];
}
