import { useEffect, useMemo, useRef, useState } from "react";
import { COLORS, DEF, KEY, computeAwards, endOf, migrate, pts, sortM, statusOf, today, totals, uid } from "./engine";
import { LineChart, Spark, Stacked } from "./charts";
import { hasBackend, supabase, loadRemote, saveRemote } from "./supabase";

const blankLine = pid => ({ pid, goals: 0, assists: 0, fouls: 0, hl: 0, mvp: false, cs: false });
const num = v => Math.max(0, +v || 0);
const persist = st => (hasBackend ? saveRemote(st) : Promise.resolve(localStorage.setItem(KEY, JSON.stringify(st))));

export default function App() {
  const [s, setS] = useState(DEF);
  const [ready, setReady] = useState(false);
  const [loadErr, setLoadErr] = useState("");
  const [session, setSession] = useState(null);
  const [saveSt, setSaveSt] = useState("");
  const dirty = useRef(false);
  const [tab, setTab] = useState("board");
  const [showLogin, setShowLogin] = useState(false);
  const [cred, setCred] = useState({ email: "", password: "" });
  const [authErr, setAuthErr] = useState("");

  // Players are read-only. Only a signed-in moderator can edit (the database enforces this too).
  const isMod = hasBackend ? !!session : true;
  const upd = patch => { dirty.current = true; setS(p => ({ ...p, ...patch })); };
  const replace = next => { dirty.current = true; setS(next); };

  /* ---------- load, auth, save ---------- */
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        if (hasBackend) {
          const { data } = await supabase.auth.getSession();
          if (alive) setSession(data.session);
          const d = await loadRemote();
          if (alive) setS(migrate(d));
        } else {
          const raw = localStorage.getItem(KEY);
          if (alive && raw) setS(migrate(JSON.parse(raw)));
        }
      } catch (e) {
        if (alive) setLoadErr("Could not load the data. Check your connection and refresh.");
      }
      if (alive) setReady(true);
    })();
    if (!hasBackend) return () => { alive = false; };
    const { data: sub } = supabase.auth.onAuthStateChange((_e, sess) => setSession(sess));
    return () => { alive = false; sub.subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    if (!hasBackend || isMod) return;
    const t = setInterval(() => loadRemote().then(d => setS(migrate(d))).catch(() => {}), 30000);
    return () => clearInterval(t);
  }, [isMod]);

  useEffect(() => {
    if (!ready || !isMod || !dirty.current) return;
    setSaveSt("saving");
    const t = setTimeout(async () => {
      try { await persist(s); dirty.current = false; setSaveSt("saved"); } catch (e) { setSaveSt("error"); }
    }, 600);
    return () => clearTimeout(t);
  }, [s, ready, isMod]);

  const login = async e => {
    e.preventDefault(); setAuthErr("");
    const { error } = await supabase.auth.signInWithPassword(cred);
    if (error) return setAuthErr("Wrong email or password.");
    try { setS(migrate(await loadRemote())); } catch (x) { /* keep current data */ }
    setShowLogin(false); setCred({ email: "", password: "" });
  };
  const logout = () => supabase.auth.signOut();

  /* ---------- helpers ---------- */
  const sc = s.scoring;
  const pName = id => (s.players.find(p => p.id === id) || { name: "?" }).name;
  const tour = id => s.tournaments.find(t => t.id === id);
  const tourLabel = id => { const t = tour(id); if (!t) return "?"; const se = s.seasons.find(x => x.id === t.seasonId); return (se ? se.name : "?") + " · " + t.name; };

  /* ---------- leaderboard ---------- */
  const [seasonF, setSeasonF] = useState("all");
  const [tourF, setTourF] = useState("all");
  const [sel, setSel] = useState(null);
  const tourOpts = s.tournaments.filter(t => seasonF === "all" || t.seasonId === seasonF);
  const inView = useMemo(() => s.matches.filter(m => {
    const t = s.tournaments.find(x => x.id === m.tid); if (!t) return false;
    if (seasonF !== "all" && t.seasonId !== seasonF) return false;
    if (tourF !== "all" && m.tid !== tourF) return false;
    return true;
  }), [s.matches, s.tournaments, seasonF, tourF]);
  const tot = useMemo(() => totals(inView, sc), [inView, sc]);
  const board = useMemo(() => s.players
    .map(p => ({ ...p, t: tot[p.id] || { pts: 0, g: 0, a: 0, mvp: 0, hl: 0, hlp: 0, f: 0, cs: 0, m: 0 } }))
    .sort((a, b) => b.t.pts - a.t.pts || a.name.localeCompare(b.name)), [s.players, tot]);
  const selP = s.players.find(p => p.id === sel);
  const history = useMemo(() => {
    if (!selP) return [];
    let r = s.start; const h = [{ r, d: "start" }];
    sortM(inView).forEach(m => m.lines.forEach(l => { if (l.pid === selP.id) { r += pts(l, sc); h.push({ r, d: m.date }); } }));
    return h;
  }, [selP, inView, s.start, sc]);

  const filters = (
    <div className="row2">
      <label>Season<select value={seasonF} onChange={e => { setSeasonF(e.target.value); setTourF("all"); }}><option value="all">All time</option>{s.seasons.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}</select></label>
      <label>Tournament<select value={tourF} onChange={e => setTourF(e.target.value)}><option value="all">All tournaments</option>{tourOpts.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label>
    </div>
  );

  /* ---------- graphs & awards ---------- */
  const [chosen, setChosen] = useState(null);
  const [awSeason, setAwSeason] = useState(null);
  const topIds = n => board.slice(0, n).map(p => p.id);
  const gIds = (chosen || topIds(5)).filter(id => s.players.some(p => p.id === id));
  const gms = sortM(inView);
  const gDates = ["start", ...new Set(gms.map(m => m.date))];
  const series = gIds.map((id, k) => {
    let r = s.start; const ys = [r];
    gDates.slice(1).forEach(d => { gms.filter(m => m.date === d).forEach(m => m.lines.forEach(l => { if (l.pid === id) r += pts(l, sc); })); ys.push(r); });
    return { id, name: pName(id), color: COLORS[k % COLORS.length], ys };
  });
  const awId = awSeason || (s.seasons[s.seasons.length - 1] || {}).id;
  const awSe = s.seasons.find(x => x.id === awId);
  const seasonAwards = se => computeAwards(s.matches.filter(m => (tour(m.tid) || {}).seasonId === se.id), s.players, sc);
  const awards = awSe ? seasonAwards(awSe) : [];

  /* ---------- log match (moderator) ---------- */
  const [lm, setLm] = useState({ tid: "", date: today(), title: "", lines: [] });
  const [addPid, setAddPid] = useState("");
  const [err, setErr] = useState("");
  const lmTid = lm.tid || (s.tournaments[0] || {}).id;
  const lmSeason = s.seasons.find(x => x.id === (tour(lmTid) || {}).seasonId);
  const setLine = (i, patch) => setLm({ ...lm, lines: lm.lines.map((l, j) => (j === i ? { ...l, ...patch } : l)) });
  const addLine = () => {
    if (!addPid) return;
    if (lm.lines.some(l => l.pid === addPid)) return setErr(pName(addPid) + " is already in this match.");
    setLm({ ...lm, lines: [...lm.lines, blankLine(addPid)] }); setAddPid(""); setErr("");
  };
  const saveMatch = e => {
    e.preventDefault();
    const tid = lmTid;
    if (!tid) return setErr("Create a tournament first (Seasons tab).");
    const se0 = s.seasons.find(x => x.id === (tour(tid) || {}).seasonId);
    if (se0 && (lm.date < se0.start || lm.date > endOf(se0.start))) return setErr("This date is outside " + se0.name + " (" + se0.start + " to " + endOf(se0.start) + ").");
    if (!lm.lines.length) return setErr("Add at least one player.");
    upd({ matches: [...s.matches, { id: uid(), tid, date: lm.date, title: lm.title.trim(), lines: lm.lines }] });
    setLm({ ...lm, title: "", lines: [] }); setErr("");
  };

  /* ---------- players, seasons (moderator) ---------- */
  const [bulk, setBulk] = useState("");
  const addPlayers = () => {
    const have = new Set(s.players.map(p => p.name.toLowerCase()));
    const uniq = [...new Set(bulk.split(/\n|,/).map(x => x.trim()).filter(x => x && !have.has(x.toLowerCase())))];
    if (uniq.length) upd({ players: [...s.players, ...uniq.map(name => ({ id: uid(), name }))] });
    setBulk("");
  };
  const delPlayer = id => {
    if (!confirm("Remove " + pName(id) + " and their stats?")) return;
    upd({ players: s.players.filter(p => p.id !== id), matches: s.matches.map(m => ({ ...m, lines: m.lines.filter(l => l.pid !== id) })) });
    setSel(null);
  };
  const [newSeason, setNewSeason] = useState("");
  const [newStart, setNewStart] = useState(today());
  const [ntSeason, setNtSeason] = useState("");
  const [ntName, setNtName] = useState("");
  const addSeason = () => {
    const n = newSeason.trim(); if (!n || !newStart) return;
    upd({ seasons: [...s.seasons, { id: uid(), name: n, start: newStart }] }); setNewSeason("");
  };
  const addTour = () => {
    const n = ntName.trim(), sid = ntSeason || (s.seasons[0] || {}).id; if (!n || !sid) return;
    upd({ tournaments: [...s.tournaments, { id: uid(), seasonId: sid, name: n }] }); setNtName("");
  };
  const delSeason = id => {
    if (!confirm("Delete this season, its tournaments and all their matches?")) return;
    const tids = s.tournaments.filter(t => t.seasonId === id).map(t => t.id);
    upd({ seasons: s.seasons.filter(x => x.id !== id), tournaments: s.tournaments.filter(t => t.seasonId !== id), matches: s.matches.filter(m => !tids.includes(m.tid)) });
    setSeasonF("all"); setTourF("all");
  };
  const delTour = id => {
    if (!confirm("Delete this tournament and its matches?")) return;
    upd({ tournaments: s.tournaments.filter(t => t.id !== id), matches: s.matches.filter(m => m.tid !== id) }); setTourF("all");
  };
  const leader = tid => {
    const t = totals(s.matches.filter(m => m.tid === tid), sc);
    const best = Object.entries(t).sort((a, b) => b[1].pts - a[1].pts)[0];
    return best ? pName(best[0]) + " (" + best[1].pts + " pts)" : "No matches yet";
  };

  /* ---------- scoring & data (moderator) ---------- */
  const setSc = (k, v) => upd({ scoring: { ...sc, [k]: v } });
  const exportJson = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(s, null, 2)], { type: "application/json" }));
    a.download = "class-elo-data.json"; a.click();
  };
  const importJson = e => {
    const f = e.target.files[0]; if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      try { const d = JSON.parse(r.result); if (!d.players || !d.matches || !d.seasons) throw 0; replace(migrate(d)); }
      catch (x) { alert("That file isn't valid class Elo data."); }
    };
    r.readAsText(f);
  };
  const reset = () => { if (confirm("Erase everything for everyone?")) replace(migrate(null)); };

  /* ---------- tabs ---------- */
  const tabs = [["board", "Leaderboard"], ["graphs", "Graphs"], ["awards", "Awards"], ["matches", "Matches"], ["seasons", "Seasons"], ...(isMod ? [["players", "Players"]] : []), ["rules", isMod ? "Scoring & data" : "Scoring"]];
  const cur = tabs.some(t => t[0] === tab) ? tab : "board";

  if (!ready) return <div className="wrap"><h1>Class Elo</h1><p className="sub">Loading…</p></div>;

  return (
    <div className="wrap">
      <div className="top">
        <div>
          <h1>Class Elo</h1>
          <p className="sub">Everyone starts at {s.start}. Goals, assists, clean sheets and highlights push your Elo up; fouls pull it down.</p>
        </div>
        <div className="who">
          {!hasBackend && <span className="badge">Demo mode: data stays in this browser</span>}
          {hasBackend && !isMod && <span className="badge">View only</span>}
          {hasBackend && isMod && <span className="badge">Moderator{session && session.user.email ? ": " + session.user.email : ""}</span>}
          {isMod && saveSt === "saving" && <span>Saving…</span>}
          {isMod && saveSt === "saved" && <span className="up">Saved</span>}
          {isMod && saveSt === "error" && <span className="down" role="alert">Save failed. Are you signed in as the moderator?</span>}
          {hasBackend && !isMod && <button className="ghost" onClick={() => setShowLogin(v => !v)}>Moderator login</button>}
          {hasBackend && isMod && <button className="ghost" onClick={logout}>Log out</button>}
        </div>
      </div>

      {loadErr && <div className="panel err" role="alert">{loadErr}</div>}

      {hasBackend && !isMod && showLogin && (
        <div className="panel login">
          <h2>Moderator login</h2>
          <form onSubmit={login}>
            <label>Email<input type="email" value={cred.email} onChange={e => setCred({ ...cred, email: e.target.value })} autoComplete="username" required /></label>
            <label>Password<input type="password" value={cred.password} onChange={e => setCred({ ...cred, password: e.target.value })} autoComplete="current-password" required /></label>
            <button className="pri" type="submit">Log in</button>
            <div className="err" role="alert">{authErr}</div>
          </form>
        </div>
      )}

      <div className="tabs" role="tablist">{tabs.map(([k, l]) => <button key={k} role="tab" aria-selected={cur === k} className={cur === k ? "on" : ""} onClick={() => setTab(k)}>{l}</button>)}</div>

      {cur === "board" && <>
        <div className="panel">
          {filters}
          {board.length > 0 && board[0].t.m > 0 && (
            <div className="podium">{board.slice(0, 3).map((p, i) => <div key={p.id} className="pod"><span className="rank">{["1st", "2nd", "3rd"][i]}</span><b>{p.name}</b><span className="elo">{s.start + p.t.pts}</span></div>)}</div>
          )}
          {board.length === 0 ? <div className="empty">No players yet.</div> : (
            <div className="scroll"><table>
              <thead><tr><th></th><th>Player</th><th className="num">Elo</th><th className="num">Pts</th><th className="num">GP</th><th className="num">Goals</th><th className="num">Assists</th><th className="num">MVP</th><th className="num">Highlights</th><th className="num">Clean sheets</th><th className="num">Fouls</th></tr></thead>
              <tbody>{board.map((p, i) => (
                <tr key={p.id} className={"row" + (sel === p.id ? " sel" : "")} tabIndex={0} onClick={() => setSel(p.id)} onKeyDown={e => e.key === "Enter" && setSel(p.id)}>
                  <td className="rank">{i + 1}</td><td><b>{p.name}</b></td>
                  <td className="num elo">{s.start + p.t.pts}</td>
                  <td className={"num " + (p.t.pts > 0 ? "up" : p.t.pts < 0 ? "down" : "flat")}>{p.t.pts > 0 ? "+" : ""}{p.t.pts}</td>
                  <td className="num">{p.t.m}</td><td className="num">{p.t.g}</td><td className="num">{p.t.a}</td><td className="num">{p.t.mvp}</td><td className="num">{p.t.hl}</td><td className="num">{p.t.cs}</td><td className="num">{p.t.f}</td>
                </tr>))}</tbody>
            </table></div>
          )}
        </div>
        {selP && <div className="panel"><h2>{selP.name}: Elo history</h2><Spark points={history} /></div>}
      </>}

      {cur === "graphs" && <>
        <div className="panel">
          {filters}
          <h2>Elo over time</h2>
          <div className="btns" style={{ marginBottom: 10 }}>
            <button className="ghost" onClick={() => setChosen(null)}>Top 5</button>
            <button className="ghost" onClick={() => setChosen(topIds(10))}>Top 10</button>
            <button className="ghost" onClick={() => setChosen([])}>Clear</button>
          </div>
          <div>{board.map(p => {
            const i = gIds.indexOf(p.id);
            return <button key={p.id} className={"chip" + (i >= 0 ? " on" : "")} style={i >= 0 ? { background: COLORS[i % COLORS.length] } : {}} onClick={() => setChosen(i >= 0 ? gIds.filter(x => x !== p.id) : [...gIds, p.id])}>{p.name}</button>;
          })}</div>
          <LineChart series={series} labels={gDates} />
        </div>
        <div className="panel">
          <h2>Where the points come from</h2>
          <p className="sub">Top 12 players in this view. The number on the right is net points, including fouls.</p>
          <Stacked rows={board.slice(0, 12)} sc={sc} />
        </div>
      </>}

      {cur === "awards" && <>
        <div className="panel">
          <div className="row2"><label>Season<select value={awId || ""} onChange={e => setAwSeason(e.target.value)}>{s.seasons.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}</select></label></div>
          {awSe && <p className="sub">{awSe.start} to {endOf(awSe.start)} · {statusOf(awSe)}. {today() > endOf(awSe.start) ? "Final awards." : "Standings so far; awards are final when the season ends."}</p>}
          <div className="awards">{awards.map(a => (
            <div className="award" key={a.title}>
              <h3>{a.title}</h3><div className="desc">{a.desc}</div>
              {a.top.length === 0 ? <div className="empty">No winner yet</div> : a.top.map((x, i) => <div key={i} className={i === 0 ? "win" : "run"}>{i === 0 ? "🏆 " : (i + 1) + ". "}{x.name} <span>{x.val} {a.unit}</span></div>)}
            </div>))}</div>
        </div>
        <div className="panel">
          <h2>Hall of fame</h2>
          <div className="scroll"><table>
            <thead><tr><th>Season</th>{awards.map(a => <th key={a.title}>{a.title}</th>)}</tr></thead>
            <tbody>{[...s.seasons].sort((a, b) => b.start.localeCompare(a.start)).map(se => (
              <tr key={se.id}><td><b>{se.name}</b>{today() <= endOf(se.start) ? " (so far)" : ""}</td>{seasonAwards(se).map(a => <td key={a.title}>{a.top[0] ? a.top[0].name : "–"}</td>)}</tr>))}</tbody>
          </table></div>
        </div>
      </>}

      {cur === "matches" && <>
        {isMod && (
          <div className="panel">
            <h2>Log a match</h2>
            <form onSubmit={saveMatch}>
              <div className="row2">
                <label>Tournament<select value={lm.tid} onChange={e => setLm({ ...lm, tid: e.target.value })}>{s.tournaments.map(t => <option key={t.id} value={t.id}>{tourLabel(t.id)}</option>)}</select></label>
                <label>Date<input type="date" value={lm.date} min={lmSeason && lmSeason.start} max={lmSeason && endOf(lmSeason.start)} onChange={e => setLm({ ...lm, date: e.target.value })} required /></label>
                <label>Match name (optional)<input value={lm.title} onChange={e => setLm({ ...lm, title: e.target.value })} placeholder="Blue vs Red" /></label>
              </div>
              <div className="row2">
                <label>Add a player<select value={addPid} onChange={e => setAddPid(e.target.value)}><option value="">Choose…</option>{s.players.filter(p => !lm.lines.some(l => l.pid === p.id)).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
                <button type="button" className="ghost" onClick={addLine}>Add to match</button>
                <button type="button" className="ghost" onClick={() => setLm({ ...lm, lines: [...lm.lines, ...s.players.filter(p => !lm.lines.some(l => l.pid === p.id)).map(p => blankLine(p.id))] })}>Add everyone</button>
              </div>
              {lm.lines.length > 0 && (
                <div className="scroll"><table>
                  <thead><tr><th>Player</th><th>Goals</th><th>Assists</th><th>Fouls</th><th>Highlight</th><th>MVP</th><th>Clean sheet</th><th className="num">Points</th><th></th></tr></thead>
                  <tbody>{lm.lines.map((l, i) => (
                    <tr key={l.pid}>
                      <td><b>{pName(l.pid)}</b></td>
                      <td><input className="n" type="number" min="0" value={l.goals} onChange={e => setLine(i, { goals: num(e.target.value) })} aria-label="Goals" /></td>
                      <td><input className="n" type="number" min="0" value={l.assists} onChange={e => setLine(i, { assists: num(e.target.value) })} aria-label="Assists" /></td>
                      <td><input className="n" type="number" min="0" value={l.fouls} onChange={e => setLine(i, { fouls: num(e.target.value) })} aria-label="Fouls" /></td>
                      <td><select value={l.hl} onChange={e => setLine(i, { hl: +e.target.value })} aria-label="Highlight points"><option value={0}>None</option>{[3, 4, 5, 6, 7, 8, 9, 10].map(v => <option key={v} value={v}>+{v}</option>)}</select></td>
                      <td><input type="checkbox" checked={l.mvp} onChange={e => setLine(i, { mvp: e.target.checked })} aria-label="MVP" /></td>
                      <td><input type="checkbox" checked={l.cs} onChange={e => setLine(i, { cs: e.target.checked })} aria-label="Clean sheet" /></td>
                      <td className="num"><b>{pts(l, sc)}</b></td>
                      <td><button type="button" className="x" aria-label="Remove from match" onClick={() => setLm({ ...lm, lines: lm.lines.filter((_, j) => j !== i) })}>✕</button></td>
                    </tr>))}</tbody>
                </table></div>
              )}
              <div className="row2" style={{ marginTop: 12 }}><button className="pri" type="submit">Save match</button></div>
              <div className="err" role="alert">{err}</div>
            </form>
          </div>
        )}
        <div className="panel">
          <h2>Match history</h2>
          {s.matches.length === 0 ? <div className="empty">No matches logged yet.</div> : sortM(s.matches).reverse().map(m => (
            <div key={m.id} style={{ borderBottom: "1px solid var(--line)", padding: "8px 0" }}>
              <div className="item" style={{ border: 0 }}>
                <div><b>{m.date}</b> · {tourLabel(m.tid)}{m.title ? " · " + m.title : ""}</div>
                {isMod && <button className="x" aria-label="Delete match" onClick={() => confirm("Delete this match?") && upd({ matches: s.matches.filter(x => x.id !== m.id) })}>✕</button>}
              </div>
              <div>{m.lines.map(l => { const p = pts(l, sc); return <span className="pill" key={l.pid}>{pName(l.pid)} {p > 0 ? "+" : ""}{p}</span>; })}</div>
            </div>))}
        </div>
      </>}

      {cur === "seasons" && <>
        {isMod && (
          <div className="grid2">
            <div className="panel">
              <h2>New season</h2>
              <p className="sub">A season lasts 2 months from its start date.</p>
              <div className="row2">
                <label>Name<input value={newSeason} onChange={e => setNewSeason(e.target.value)} placeholder="Season 2" /></label>
                <label>Start date<input type="date" value={newStart} onChange={e => setNewStart(e.target.value)} /></label>
                <button className="pri" onClick={addSeason}>Add season</button>
              </div>
            </div>
            <div className="panel">
              <h2>New tournament</h2>
              <p className="sub">Tournaments belong to a season.</p>
              <div className="row2">
                <label>Season<select value={ntSeason || (s.seasons[0] || {}).id || ""} onChange={e => setNtSeason(e.target.value)}>{s.seasons.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}</select></label>
                <label>Name<input value={ntName} onChange={e => setNtName(e.target.value)} placeholder="Winter Cup" /></label>
                <button className="pri" onClick={addTour}>Add tournament</button>
              </div>
            </div>
          </div>
        )}
        {[...s.seasons].sort((a, b) => b.start.localeCompare(a.start)).map(se => (
          <div className="panel" key={se.id}>
            <div className="item" style={{ border: 0 }}>
              <div><h2 style={{ margin: 0 }}>{se.name}</h2><span className="sub" style={{ margin: 0 }}>{se.start} to {endOf(se.start)} · {statusOf(se)}</span></div>
              <div className="btns">
                <button className="ghost" onClick={() => { setAwSeason(se.id); setTab("awards"); }}>Awards</button>
                {isMod && <button className="ghost" onClick={() => delSeason(se.id)}>Delete</button>}
              </div>
            </div>
            {isMod && <div className="row2" style={{ marginTop: 8 }}><label>Start date<input type="date" value={se.start} onChange={e => e.target.value && upd({ seasons: s.seasons.map(x => (x.id === se.id ? { ...x, start: e.target.value } : x)) })} /></label></div>}
            {s.tournaments.filter(t => t.seasonId === se.id).length === 0 && <div className="empty">No tournaments yet.</div>}
            {s.tournaments.filter(t => t.seasonId === se.id).map(t => (
              <div className="item" key={t.id}>
                <span><b>{t.name}</b> · {s.matches.filter(m => m.tid === t.id).length} matches · leader: {leader(t.id)}</span>
                {isMod && <button className="x" aria-label="Delete tournament" onClick={() => delTour(t.id)}>✕</button>}
              </div>))}
          </div>))}
      </>}

      {cur === "players" && isMod && (
        <div className="grid2">
          <div className="panel">
            <h2>Add players</h2>
            <p className="sub">One name per line (or separated by commas). Paste your whole class at once.</p>
            <textarea value={bulk} onChange={e => setBulk(e.target.value)} aria-label="Player names" />
            <div className="row2" style={{ marginTop: 10 }}><button className="pri" onClick={addPlayers}>Add players</button></div>
          </div>
          <div className="panel">
            <h2>Class ({s.players.length})</h2>
            {s.players.length === 0 ? <div className="empty">No players yet.</div> : [...s.players].sort((a, b) => a.name.localeCompare(b.name)).map(p => (
              <div className="item" key={p.id}><span>{p.name}</span><button className="x" aria-label={"Remove " + p.name} onClick={() => delPlayer(p.id)}>✕</button></div>))}
          </div>
        </div>
      )}

      {cur === "rules" && <>
        <div className="panel">
          <h2>Scoring</h2>
          {isMod ? (
            <>
              <div className="row2">
                <label>Goal<input className="n" type="number" value={sc.goal} onChange={e => setSc("goal", +e.target.value || 0)} /></label>
                <label>Assist<input className="n" type="number" value={sc.assist} onChange={e => setSc("assist", +e.target.value || 0)} /></label>
                <label>MVP<input className="n" type="number" value={sc.mvp} onChange={e => setSc("mvp", +e.target.value || 0)} /></label>
                <label>Clean sheet<input className="n" type="number" value={sc.cs} onChange={e => setSc("cs", +e.target.value || 0)} /></label>
                <label>Foul<input className="n" type="number" value={sc.foul} onChange={e => setSc("foul", +e.target.value || 0)} /></label>
                <label>Starting Elo<input className="n" type="number" value={s.start} onChange={e => upd({ start: +e.target.value || 0 })} /></label>
              </div>
              <p className="sub">Changing a value recalculates every past match for everyone.</p>
            </>
          ) : (
            <table><tbody>
              <tr><td>Goal</td><td className="num">+{sc.goal}</td></tr>
              <tr><td>Assist</td><td className="num">+{sc.assist}</td></tr>
              <tr><td>MVP of the match</td><td className="num">+{sc.mvp}</td></tr>
              <tr><td>Highlight of the match</td><td className="num">+3 to +10</td></tr>
              <tr><td>Clean sheet</td><td className="num">+{sc.cs}</td></tr>
              <tr><td>Foul</td><td className="num">{sc.foul}</td></tr>
              <tr><td>Starting Elo</td><td className="num">{s.start}</td></tr>
            </tbody></table>
          )}
        </div>
        {isMod && (
          <div className="panel">
            <h2>Data</h2>
            <p className="sub">{hasBackend ? "Data is saved online and shown to everyone." : "Demo mode: data is saved in this browser only."} Export a backup now and then.</p>
            <div className="btns">
              <button className="ghost" onClick={exportJson}>Export backup</button>
              <label style={{ display: "inline-block" }}>
                <span style={{ display: "inline-block", padding: "8px 10px", border: "1px solid #c9d4c4", borderRadius: 6, background: "#fff", cursor: "pointer", color: "#12281b", fontWeight: 600 }}>Import backup</span>
                <input type="file" accept="application/json" onChange={importJson} style={{ display: "none" }} />
              </label>
              <button className="ghost" onClick={reset}>Erase everything</button>
            </div>
          </div>
        )}
      </>}
    </div>
  );
}
