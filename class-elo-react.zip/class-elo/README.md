# Class Elo

React + Vite site. Players see a read-only view. The moderator logs in to add players, seasons, tournaments and matches. Data lives in Supabase (free tier), so everyone sees the same live leaderboard.

You do not need to install anything on your computer: GitHub and Vercel build it for you.

## 1. Supabase (the shared database)
1. Create a free project at supabase.com.
2. Open **SQL Editor**, paste `supabase.sql`, replace `moderator@example.com` (twice) with the moderator's email, and press **Run**.
3. Open **Authentication > Users > Add user > Create new user**. Enter that same email and a strong password, and tick auto-confirm.
4. Open **Authentication > Sign In / Providers** (or Settings) and turn **off** "Allow new users to sign up".
5. Open **Project Settings > API** and copy the **Project URL** and the **anon public** key.

The anon key is safe to put in a website. What protects the data is the rule in `supabase.sql`: only the moderator's account can write.

## 2. GitHub
Create a repository and upload every file in this folder (keep the `src` folder). Do not upload a `.env` file.

## 3. Vercel
1. Import the GitHub repository at vercel.com. It detects Vite on its own.
2. Before deploying, add two Environment Variables:
   - `VITE_SUPABASE_URL` = your Project URL
   - `VITE_SUPABASE_ANON_KEY` = your anon public key
3. Press **Deploy**. Share the link with the class.

The moderator presses **Moderator login** at the top right of the site. Players never see edit buttons.

## Optional: run it on your computer
```
npm install
copy .env.example .env     (then fill in the two values)
npm run dev
```
Without the two environment variables the site starts in demo mode: everyone is a moderator and data stays in that browser. It is useful for trying things out, not for the real class site.

## Notes
- Only one moderator device should edit at a time (the last save wins).
- Players' pages refresh the data every 30 seconds.
- Use **Export backup** in Scoring & data after each match day.
