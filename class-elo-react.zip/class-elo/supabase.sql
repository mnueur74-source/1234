-- Run this once in Supabase: SQL Editor -> New query -> paste -> Run.
-- Replace BOTH copies of moderator@example.com with the moderator's real email first.

create table if not exists public.league_state (
  id int primary key check (id = 1),
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.league_state enable row level security;

-- Everyone (players included) can read.
create policy "anyone can read"
  on public.league_state for select
  using (true);

-- Only the moderator's account can write. There is no delete policy, so nobody can delete the row.
create policy "moderator can insert"
  on public.league_state for insert to authenticated
  with check ((auth.jwt() ->> 'email') = 'moderator@example.com');

create policy "moderator can update"
  on public.league_state for update to authenticated
  using ((auth.jwt() ->> 'email') = 'moderator@example.com')
  with check ((auth.jwt() ->> 'email') = 'moderator@example.com');

insert into public.league_state (id, data) values (1, '{}'::jsonb) on conflict (id) do nothing;
